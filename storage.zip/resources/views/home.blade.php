@extends('layouts.main')

@section('content')
<style>
    .chat-box {
        height: 50vh;
        overflow-y: auto;
        background-color: #e5ddd5;
        border-bottom: 1px solid #ccc;
        display: flex;
        flex-direction: column;
        gap: 8px;
        padding: 8px;
    }
</style>

<div class="min-h-screen flex items-center justify-center bg-[#ece5dd]">
    <div class="w-full max-w-md bg-white rounded-lg shadow-lg flex flex-col mb-12">
        <div class="bg-green-500 text-black text-center p-4 rounded-t-lg font-bold">
            Sinhala - Korean AI Chat
        </div>

        <div id="chat-box" class="chat-box"></div>

        <form id="chat-form" class="border-t p-3 bg-gray-100">
            <div class="flex items-center space-x-2">
                <button id="record-btn" type="button"
                    class="w-12 h-12 bg-gray-200 hover:bg-gray-300 rounded-full flex items-center justify-center">
                    <img src="https://img.icons8.com/ios-filled/24/000000/microphone.png" alt="Voice">
                </button>
                <audio id="audio-preview" controls style="display:none;"></audio>
                <textarea id="user-input" rows="1" placeholder="Type a message..."
                    class="flex-1 resize-none rounded-full px-4 py-2 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-green-400 bg-white"
                    required></textarea>

                <button type="submit"
                    class="w-12 h-12 bg-blue-500 hover:bg-blue-600 text-white rounded-full flex items-center justify-center text-xl"
                    id="send-btn">
                    ➤
                </button>
            </div>
        </form>

        <div class="text-center text-sm text-gray-500 py-2">
            Free plan: Max 20 text messages, no voice chat
        </div>
    </div>
</div>

<script>
    let recorder = null;
    let audioBlob = null;
    let recordingTimeout = null;
    let isRecording = false;
    let chunks = [];
    let addAudio = false;
    const userInput = document.getElementById('user-input');
    const recordBtn = document.getElementById('record-btn');
    const sendBtn = document.getElementById('send-btn');
    const audioPreview = document.getElementById('audio-preview');
    // Handle start recording (common to both mouse & touch)
    async function startRecording() {
        stopAndDiscardRecording(); // Clear any previous
        try {
            const stream = await navigator.mediaDevices.getUserMedia({
                audio: true
            });
            recorder = new MediaRecorder(stream);
            chunks = [];
            recorder.ondataavailable = e => {
                if (e.data.size > 0) chunks.push(e.data);
            };
            recorder.onstop = () => {
                if (chunks.length > 0) {
                    audioBlob = new Blob(chunks, {
                        type: 'audio/webm'
                    });
                    const url = URL.createObjectURL(audioBlob);
                    audioPreview.src = url;
                    audioPreview.style.display = 'block';
                    userInput.style.display = 'none';
                }
                isRecording = false;
                clearTimeout(recordingTimeout);
            };
            recorder.start();
            isRecording = true;
            // Auto stop after 2 minutes
            recordingTimeout = setTimeout(() => {
                if (recorder && recorder.state === 'recording') recorder.stop();
            }, 120000);
        } catch (err) {
            alert('Microphone access denied or error');
            console.error(err);
        }
    }
    // Handle stop recording
    function stopRecording() {
        if (isRecording && recorder && recorder.state === 'recording') {
            recorder.stop();
        }
    }
    // Mouse events
    recordBtn.addEventListener('mousedown', (e) => {
        e.preventDefault();
        e.stopPropagation();
        startRecording();
    });
    recordBtn.addEventListener('mouseup', stopRecording);
    // Touch events (mobile)
    recordBtn.addEventListener('touchstart', (e) => {
        e.preventDefault();
        e.stopPropagation();
        startRecording();
    });
    recordBtn.addEventListener('touchend', stopRecording);
    // Cancel recording if clicked elsewhere
    document.addEventListener('click', (e) => {
        if (!e.target.closest('#record-btn') && (isRecording || audioBlob)) {
            stopAndDiscardRecording();
        }
    });
    // Prevent voice button from triggering document click
    recordBtn.addEventListener('click', e => e.stopPropagation());
    // Send the recorded audio
    sendBtn.addEventListener('click', async () => {
        if (!audioBlob) return;
        const formData = new FormData();
        formData.append('audio', audioBlob, 'voice.webm');
        const res = await fetch('/chat/voice', {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
            },
            body: formData
        });
        const data = await res.json();
        if (data.text) {
            appendMessage('You (voice)', data.text, 'user-msg');
            appendMessage('AI', data.reply, 'ai-msg');
        }
        resetRecordingUI();
    });
    // Reset and discard recording
    function stopAndDiscardRecording() {
        if (recorder && recorder.state === 'recording') {
            recorder.stop();
        }
        isRecording = false;
        audioBlob = null;
        chunks = [];
        audioPreview.src = '';
        audioPreview.style.display = 'none';
        userInput.style.display = 'block';
        clearTimeout(recordingTimeout);
    }
    // After send/cancel
    function resetRecordingUI() {
        stopAndDiscardRecording();
        userInput.style.display = 'block';
    }
    // Preserve typed text even if user reloads or cancels
    window.addEventListener('beforeunload', () => {
        localStorage.setItem('userText', userInput.value);
    });
    window.addEventListener('DOMContentLoaded', () => {
        userInput.value = localStorage.getItem('userText') || '';
    });
    const chatBox = document.getElementById('chat-box');
    const chatForm = document.getElementById('chat-form');

   function getOrSetDeviceId() {
    let id = localStorage.getItem('device_id');
    if (!id) {
        id = 'device_' + Math.random().toString(36).substring(2, 11);
        localStorage.setItem('device_id', id);
    }
    return id;
}

const deviceId = getOrSetDeviceId();
window.deviceId = deviceId; // <- optional but useful

// 🔐 Authenticate with server to get secret token
async function authenticateDevice() {
    const res = await fetch('/device/authenticate', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        },
        body: JSON.stringify({ device_id: deviceId })
    });
    const data = await res.json();
    if (data.secret_token) {
        localStorage.setItem('secret_token', data.secret_token);
    }
}

authenticateDevice(); // ✅ call once on page load

    chatForm.addEventListener('submit', async (e) => {
        e.preventDefault();
       const token = localStorage.getItem('secret_token');
        if (audioBlob) {
            const formData = new FormData();
            formData.append('audio', audioBlob, 'voice.webm');
            formData.append('device_id', deviceId);
            try {
                const res = await fetch('/chat/voice', {
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    },
                    body: formData
                });
                console.log('Response status:', res.status);
                const responseText = await res.clone().text();
                console.log('Raw response:', responseText);
                if (res.status === 403) {
                    const data = await res.json();
                    window.location.href = "/subscribe";
                    return;
                }
                const data = await res.json();
                if (data.text) {
                    appendMessage('You (voice)', data.text, 'user-msg');
                    appendMessage('AI', data.reply, 'ai-msg');
                }
                resetRecordingUI();
            } catch (error) {
                alert('Error sending voice message');
                console.error(error);
            }
            return; // Stop further execution to prevent text sending
        }
        // Else, send text message
        const message = userInput.value.trim();
        if (!message) return;
        appendMessage('You', message, 'user-msg');
        userInput.value = '';
        try {
            const res = await fetch('/chat/send', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'X-DEVICE-TOKEN': token
                },
                body: JSON.stringify({
                    device_id: deviceId,
                    message: message,
                })
            });
            if (res.status === 429) {
                const data = await res.json();
                window.location.href = "/subscribe";
                return;
            }
            const data = await res.json();
            appendMessage('AI', data.reply, 'ai-msg');
        } catch (error) {
            alert('Error sending message');
            console.error(error);
        }
    });

    function appendMessage(sender, message, type) {
        const div = document.createElement('div');
        div.className = type === 'user-msg' ?
            'bg-green-200 text-right p-2 rounded-lg self-end max-w-[70%] ml-auto' :
            'bg-white text-left p-2 rounded-lg self-start max-w-[70%] mr-auto';
        div.textContent = (sender === 'You' ? '' : '🤖 ') + message;
        chatBox.appendChild(div);
        chatBox.scrollTop = chatBox.scrollHeight;
    }
</script>
@endsection