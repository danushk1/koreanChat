@extends('layouts.main')

@section('content')
<div style="display: flex; height: 100vh;">

    {{-- Sidebar: Show user's projects --}}
    <div style="width: 25%; background-color: #f1f5f9; padding: 15px;">
        <h5>Your Projects</h5>
        <select name="project_id" class="form-select">
    @foreach($projects as $p)
        <option value="{{ $p->project_name }}" {{ $p->id == $currentProject->id ? 'selected' : '' }}>
            {{ $p->project_name }}
        </option>
    @endforeach
</select>


    </div>
    {{-- Canvas Area --}}
    <div style="width: 75%; padding: 20px;">

       <form id="queryForm" method="POST" action="{{ route('projects.generateQuery', $currentProject->id) }}">
    @csrf
    <div class="mb-3">
        <label for="prompt">Describe what you want</label>
        <textarea name="prompt" rows="3" class="form-control" required placeholder="e.g., Show item name and quantity..."></textarea>
    </div>
    <button type="submit" class="btn btn-success">Generate SQL</button>
</form>

        @if(session('generated_sql'))
        <hr>
        <h5>Generated SQL:</h5>
        <pre style="background: #f8f9fa; padding: 15px; border: 1px solid #ddd;">
        {{ session('generated_sql') }}
        </pre>
        @endif
    </div>
</div>
<script>
    document.getElementById('queryForm').addEventListener('submit', function (e) {
        const select = document.querySelector('select[name="project_id"]');
        const selectedProjectId = select.value;

        // Laravel route template string
        const routeTemplate = @json(route('projects.generateQuery', ['id' => '__ID__']));

        // Replace placeholder with selected ID
        this.action = routeTemplate.replace('__ID__', selectedProjectId);
    });
</script>
@endsection