<!-- resources/views/subscribe.blade.php -->
@extends('layouts.main')

@section('content')
<div class="flex flex-col items-center justify-center min-h-screen">
    <h1 class="text-2xl font-bold mb-4">Upgrade to Unlimited Plan</h1>
    <form method="POST" action="/subscribe/payhere">
        @csrf
        <button type="submit" class="bg-green-500 text-white px-6 py-2 rounded-lg">
            Pay Now (Rs. 500)
        </button>
    </form>
</div>
@endsection
