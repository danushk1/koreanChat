@extends('layouts.main')

@section('content')
<div class="container">
    <h2>Create New Project</h2>
    <form method="POST" action="{{ route('projects.store') }}" enctype="multipart/form-data">
        @csrf

        <div class="mb-3">
            <label for="project_name">Project Name</label>
            <input type="text" name="project_name" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="database_file">Upload Database File (excel)</label>
            <input type="file" name="database_file" class="form-control" required>
        </div>

        <button type="submit" class="btn btn-primary">Create Project</button>
    </form>
</div>
@endsection
