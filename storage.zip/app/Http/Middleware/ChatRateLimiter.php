<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\DB;
use App\Models\Subscription;
use Illuminate\Support\Facades\Auth;

class ChatRateLimiter
{
    public function handle($request, Closure $next)
    {
        $deviceId = $request->input('device_id');
        $token = $request->header('X-DEVICE-TOKEN');

        if (!$deviceId || !$token) {
            return response()->json(['message' => 'Device ID or token missing'], 400);
        }

        $today = now()->toDateString();

        $record = DB::table('devices')
            ->where('device_id', $deviceId)
            ->where('secret_token', $token)
            ->where('date', $today)
            ->first();

        if (!$record) {
            return response()->json(['message' => 'Invalid or expired token'], 403);
        }

        // ✅ Check paid subscription
        $user = Auth::user();
        $sub = Subscription::where(function ($q) use ($deviceId) {
            $q->where('fingerprint_id', $deviceId)
              ->where('is_active', true)
              ->where('end_date', '>=', now());
        })->orWhere(function ($q) use ($user) {
            $q->where('user_id', optional($user)->id)
              ->where('is_active', true)
              ->where('end_date', '>=', now());
        })->first();

        if ($sub) {
            return $next($request); // 🔓 Unlimited for paid
        }

        // 🚫 Free plan limit
        if ($record->usage_count >= 20) {
            return response()->json(['message' => 'Daily free limit reached. Please upgrade.'], 429);
        }

        DB::table('devices')->where('id', $record->id)->update([
            'usage_count' => $record->usage_count + 1,
            'last_used_at' => now(),
        ]);

        return $next($request);
    }
}
