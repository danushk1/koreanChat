<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Models\Subscription;
use Illuminate\Support\Facades\Auth;

class OnlyPaidVoiceChat
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next)
    {
        $fingerprint = $request->input('device_id');
        $user = Auth::user();

        $hasValidSub = Subscription::where(function ($q) use ($fingerprint) {
            $q->where('fingerprint_id', $fingerprint)
              ->where('is_active', true)
              ->where('end_date', '>=', now());
        })->orWhere(function ($q) use ($user) {
            $q->where('user_id', optional($user)->id)
              ->where('is_active', true)
              ->where('end_date', '>=', now());
        })->exists();

        if (!$hasValidSub) {
            return response()->json([
                'message' => 'Voice chat is only available for paid users.'
            ], 403);
        }

        return $next($request);
    }
}
