<?php

namespace App\Http\Controllers;

use App\Models\project;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Http;

class ProjectController extends Controller
{
  public function create()
    {
        return view('firstquaryproject');
    }

    public function store(Request $request)
    {
$excel = Excel::toArray([], $request->file('database_file'));
    $sheet = $excel[0];

    $schema = [];

    foreach ($sheet as $row) {
        if (count($row) >= 2) {
            $table = trim($row[0]);
            $column = trim($row[1]);
            $schema[$table][] = $column;
        }
    }
//dd(Auth::id());
  $id = DB::table('project_schemas')->insertGetId([
    'user_id' => Auth::id(),
    'project_name' => $request->project_name,
    'schema_json' => json_encode($schema),
    'created_at' => now(),
    'updated_at' => now()
]);

return redirect()->route('projects.canvas');
}

public function canvas()
{
    $projects = DB::table('project_schemas')
        ->where('user_id', Auth::id())
->get();

    if (!$projects) {
        abort(404);
    }

    $currentProject = $projects->first();

    return view('project_canvas', [
        'projects' => $projects,
        'currentProject' => $currentProject
    ]);
}



    public function generateQuery(Request $request, $projectName)
{/*item history quantity,item name,location name,branch name */

$user_id = Auth::id();
    $request->validate(['prompt' => 'required|string']);

    $project =DB::select("SELECT * FROM project_schemas WHERE user_id= $user_id AND project_name= '$projectName'");
        

    if (!$project) {
        return back()->with('error', 'Project not found.');
    }
$project = $project[0]; // first project

    $schema = json_decode($project->schema_json, true);

    if (!$schema) {
        return back()->with('error', 'Invalid project schema.');
    }

    // Build schema text for prompt
    $schemaText = "";
    foreach ($schema as $table => $columns) {
        $schemaText .= "Table: $table → " . implode(', ', $columns) . "\n";
    }

    // Final prompt to send to AI
    $finalPrompt = <<<EOT
Given the following database schema:
$schemaText

Write an optimized SQL query for:
{$request->prompt}
EOT;

    // Call OpenAI
  $response = Http::withToken(env('OPENAI_API_KEY'))
        ->post('https://api.openai.com/v1/chat/completions', [
            'model' => 'gpt-4',
            'messages' => [
                ['role' => 'system', 'content' => 'You are a SQL expert.'],
                ['role' => 'user', 'content' => $finalPrompt],
            ],
        ]);

    $sql = $response['choices'][0]['message']['content'] ?? 'Error generating SQL.';

    return back()->with('generated_sql', $sql);
}

}


