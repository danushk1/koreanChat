<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ChatController extends Controller
{
    public function send(Request $request)
    {
        $request->validate([
            'device_id' => 'required|string',
            'message' => 'required|string',
        ]);

        $message = $request->input('message');

        // TODO: Replace below with OpenAI API call
        $reply = "You said: " . $message;

        return response()->json([
            'reply' => $reply,
        ]);
    }

public function handleVoice(Request $request)
{
dd($request->all());

    if (!$request->hasFile('audio')) {
        return response()->json(['error' => 'No audio file'], 400);
    }

    $path = $request->file('audio')->store('voices');

    // Convert WebM to MP3 or WAV if needed
    $convertedPath = storage_path("app/{$path}");
    
    // Call OpenAI Whisper
    $result = OpenAI::audio()->transcribe([
        'file' => fopen($convertedPath, 'r'),
        'model' => 'whisper-1',
        'language' => 'si', // or 'ko' for Korean
    ]);

    $text = $result['text'];

    // Now respond with AI reply
    $reply = $this->askAI($text); // Your existing function

    return response()->json([
        'text' => $text,
        'reply' => $reply,
    ]);
}
}
