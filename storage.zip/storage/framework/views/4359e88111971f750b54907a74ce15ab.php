

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Create New Project</h2>
    <form method="POST" action="<?php echo e(route('projects.store')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label for="project_name">Project Name</label>
            <input type="text" name="project_name" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="database_file">Upload Database File (excel)</label>
            <input type="file" name="database_file" class="form-control" required>
        </div>

        <button type="submit" class="btn btn-primary">Create Project</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Danushkasupun\OneDrive\Desktop\Tool\koreanChatApp\resources\views/firstquaryproject.blade.php ENDPATH**/ ?>