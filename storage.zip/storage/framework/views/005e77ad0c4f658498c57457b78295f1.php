<!-- resources/views/subscribe.blade.php -->


<?php $__env->startSection('content'); ?>
<div class="flex flex-col items-center justify-center min-h-screen">
    <h1 class="text-2xl font-bold mb-4">Upgrade to Unlimited Plan</h1>
    <form method="POST" action="/subscribe/payhere">
        <?php echo csrf_field(); ?>
        <button type="submit" class="bg-green-500 text-white px-6 py-2 rounded-lg">
            Pay Now (Rs. 500)
        </button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Danushkasupun\OneDrive\Desktop\Tool\koreanChatApp\resources\views/subscribe.blade.php ENDPATH**/ ?>