<nav class="bg-gray-500 shadow mb-4">
    <div class="container mx-auto px-4 py-3 flex justify-between items-center">
        <a href="<?php echo e(route('home')); ?>" class="text-xl font-bold">Home</a>
        
 <a href="<?php echo e(route('home')); ?>" class="text-gray-100">Korean Chat</a>
<a href="<?php echo e(route('projects.create')); ?>" class="text-gray-100">Project</a>
<a href="<?php echo e(route('projects.canvas')); ?>" class="text-gray-100">generate quary</a>

<div>
            <?php if(auth()->guard()->check()): ?>
                <span class="text-white mr-2">Hi, <?php echo e(Auth::user()->name); ?></span>
                <form method="POST" action="<?php echo e(route('logout')); ?>" class="inline">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="text-white hover:underline">Logout</button>
                </form>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="text-white mr-4 hover:underline">Login</a>
                <a href="<?php echo e(route('register')); ?>" class="text-white hover:underline">Register</a>
            <?php endif; ?>
        </div>
 
    </div>
</nav><?php /**PATH C:\Users\Danushkasupun\OneDrive\Desktop\Tool\koreanChatApp\resources\views/partials/navbar.blade.php ENDPATH**/ ?>