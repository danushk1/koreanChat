

<?php $__env->startSection('content'); ?>
<div style="display: flex; height: 100vh;">

    
    <div style="width: 25%; background-color: #f1f5f9; padding: 15px;">
        <h5>Your Projects</h5>
        <select name="project_id" class="form-select">
    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($p->project_name); ?>" <?php echo e($p->id == $currentProject->id ? 'selected' : ''); ?>>
            <?php echo e($p->project_name); ?>

        </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>


    </div>
    
    <div style="width: 75%; padding: 20px;">

       <form id="queryForm" method="POST" action="<?php echo e(route('projects.generateQuery', $currentProject->id)); ?>">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="prompt">Describe what you want</label>
        <textarea name="prompt" rows="3" class="form-control" required placeholder="e.g., Show item name and quantity..."></textarea>
    </div>
    <button type="submit" class="btn btn-success">Generate SQL</button>
</form>

        <?php if(session('generated_sql')): ?>
        <hr>
        <h5>Generated SQL:</h5>
        <pre style="background: #f8f9fa; padding: 15px; border: 1px solid #ddd;">
        <?php echo e(session('generated_sql')); ?>

        </pre>
        <?php endif; ?>
    </div>
</div>
<script>
    document.getElementById('queryForm').addEventListener('submit', function (e) {
        const select = document.querySelector('select[name="project_id"]');
        const selectedProjectId = select.value;

        // Laravel route template string
        const routeTemplate = <?php echo json_encode(route('projects.generateQuery', ['id' => '__ID__']), 512) ?>;

        // Replace placeholder with selected ID
        this.action = routeTemplate.replace('__ID__', selectedProjectId);
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Danushkasupun\OneDrive\Desktop\Tool\koreanChatApp\resources\views/project_canvas.blade.php ENDPATH**/ ?>